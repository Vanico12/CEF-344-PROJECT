import React from 'react'
import"./Portfolio.css"
const Portfoilio= () => {
    return(
        <section id='portfolio'>Portfolio</section>
    )
}

export default Portfolio