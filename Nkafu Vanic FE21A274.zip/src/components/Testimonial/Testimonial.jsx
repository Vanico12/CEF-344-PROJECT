import React from 'react'
import"./Testimonial.css"
const Testimonial = () => {
    return(
        <section id='testimonial'>Testimonail</section>
    )
}

export default Testimonial