import React from 'react'
import"./Services.css"
const Services = () => {
    return(
        <section id='services'>Services</section>
    )
}

export default Services